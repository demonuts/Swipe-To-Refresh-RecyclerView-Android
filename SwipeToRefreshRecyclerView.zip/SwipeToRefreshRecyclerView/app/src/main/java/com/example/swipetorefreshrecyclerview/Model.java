package com.example.swipetorefreshrecyclerview;

/**
 * Created by Parsania Hardik on 28-Jun-17.
 */
public class Model {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
